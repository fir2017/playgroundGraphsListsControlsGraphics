﻿namespace createALinkBetweenObjectsControls
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.controlUtilizator10 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator9 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator8 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator7 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator6 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator5 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator4 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator3 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator2 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator1 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator11 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator12 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator13 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator14 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator15 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator16 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator17 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator18 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator19 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.controlUtilizator20 = new createALinkBetweenObjectsControls.controlUtilizator();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, -1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(38, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "ab";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 29);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(38, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "cb";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 59);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(38, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "clr";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(3, 89);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(38, 23);
            this.button4.TabIndex = 7;
            this.button4.Text = "all";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // controlUtilizator10
            // 
            this.controlUtilizator10.BackColor = System.Drawing.Color.White;
            this.controlUtilizator10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator10.Location = new System.Drawing.Point(191, 49);
            this.controlUtilizator10.Name = "controlUtilizator10";
            this.controlUtilizator10.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator10.TabIndex = 13;
            // 
            // controlUtilizator9
            // 
            this.controlUtilizator9.BackColor = System.Drawing.Color.White;
            this.controlUtilizator9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator9.Location = new System.Drawing.Point(370, 301);
            this.controlUtilizator9.Name = "controlUtilizator9";
            this.controlUtilizator9.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator9.TabIndex = 12;
            // 
            // controlUtilizator8
            // 
            this.controlUtilizator8.BackColor = System.Drawing.Color.White;
            this.controlUtilizator8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator8.Location = new System.Drawing.Point(425, 79);
            this.controlUtilizator8.Name = "controlUtilizator8";
            this.controlUtilizator8.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator8.TabIndex = 11;
            // 
            // controlUtilizator7
            // 
            this.controlUtilizator7.BackColor = System.Drawing.Color.White;
            this.controlUtilizator7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator7.Location = new System.Drawing.Point(161, 301);
            this.controlUtilizator7.Name = "controlUtilizator7";
            this.controlUtilizator7.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator7.TabIndex = 10;
            // 
            // controlUtilizator6
            // 
            this.controlUtilizator6.BackColor = System.Drawing.Color.White;
            this.controlUtilizator6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator6.Location = new System.Drawing.Point(290, 134);
            this.controlUtilizator6.Name = "controlUtilizator6";
            this.controlUtilizator6.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator6.TabIndex = 9;
            // 
            // controlUtilizator5
            // 
            this.controlUtilizator5.BackColor = System.Drawing.Color.White;
            this.controlUtilizator5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator5.Location = new System.Drawing.Point(162, 180);
            this.controlUtilizator5.Name = "controlUtilizator5";
            this.controlUtilizator5.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator5.TabIndex = 8;
            // 
            // controlUtilizator4
            // 
            this.controlUtilizator4.BackColor = System.Drawing.Color.White;
            this.controlUtilizator4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator4.Location = new System.Drawing.Point(309, 20);
            this.controlUtilizator4.Name = "controlUtilizator4";
            this.controlUtilizator4.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator4.TabIndex = 5;
            // 
            // controlUtilizator3
            // 
            this.controlUtilizator3.BackColor = System.Drawing.Color.White;
            this.controlUtilizator3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator3.Location = new System.Drawing.Point(96, 204);
            this.controlUtilizator3.Name = "controlUtilizator3";
            this.controlUtilizator3.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator3.TabIndex = 4;
            // 
            // controlUtilizator2
            // 
            this.controlUtilizator2.BackColor = System.Drawing.Color.White;
            this.controlUtilizator2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator2.Location = new System.Drawing.Point(327, 204);
            this.controlUtilizator2.Name = "controlUtilizator2";
            this.controlUtilizator2.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator2.TabIndex = 1;
            // 
            // controlUtilizator1
            // 
            this.controlUtilizator1.BackColor = System.Drawing.Color.White;
            this.controlUtilizator1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator1.Location = new System.Drawing.Point(96, 60);
            this.controlUtilizator1.Name = "controlUtilizator1";
            this.controlUtilizator1.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator1.TabIndex = 0;
            // 
            // controlUtilizator11
            // 
            this.controlUtilizator11.BackColor = System.Drawing.Color.White;
            this.controlUtilizator11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator11.Location = new System.Drawing.Point(257, 79);
            this.controlUtilizator11.Name = "controlUtilizator11";
            this.controlUtilizator11.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator11.TabIndex = 23;
            // 
            // controlUtilizator12
            // 
            this.controlUtilizator12.BackColor = System.Drawing.Color.White;
            this.controlUtilizator12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator12.Location = new System.Drawing.Point(436, 331);
            this.controlUtilizator12.Name = "controlUtilizator12";
            this.controlUtilizator12.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator12.TabIndex = 22;
            // 
            // controlUtilizator13
            // 
            this.controlUtilizator13.BackColor = System.Drawing.Color.White;
            this.controlUtilizator13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator13.Location = new System.Drawing.Point(491, 109);
            this.controlUtilizator13.Name = "controlUtilizator13";
            this.controlUtilizator13.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator13.TabIndex = 21;
            // 
            // controlUtilizator14
            // 
            this.controlUtilizator14.BackColor = System.Drawing.Color.White;
            this.controlUtilizator14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator14.Location = new System.Drawing.Point(227, 331);
            this.controlUtilizator14.Name = "controlUtilizator14";
            this.controlUtilizator14.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator14.TabIndex = 20;
            // 
            // controlUtilizator15
            // 
            this.controlUtilizator15.BackColor = System.Drawing.Color.White;
            this.controlUtilizator15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator15.Location = new System.Drawing.Point(356, 164);
            this.controlUtilizator15.Name = "controlUtilizator15";
            this.controlUtilizator15.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator15.TabIndex = 19;
            // 
            // controlUtilizator16
            // 
            this.controlUtilizator16.BackColor = System.Drawing.Color.White;
            this.controlUtilizator16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator16.Location = new System.Drawing.Point(228, 210);
            this.controlUtilizator16.Name = "controlUtilizator16";
            this.controlUtilizator16.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator16.TabIndex = 18;
            // 
            // controlUtilizator17
            // 
            this.controlUtilizator17.BackColor = System.Drawing.Color.White;
            this.controlUtilizator17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator17.Location = new System.Drawing.Point(375, 50);
            this.controlUtilizator17.Name = "controlUtilizator17";
            this.controlUtilizator17.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator17.TabIndex = 17;
            // 
            // controlUtilizator18
            // 
            this.controlUtilizator18.BackColor = System.Drawing.Color.White;
            this.controlUtilizator18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator18.Location = new System.Drawing.Point(162, 234);
            this.controlUtilizator18.Name = "controlUtilizator18";
            this.controlUtilizator18.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator18.TabIndex = 16;
            // 
            // controlUtilizator19
            // 
            this.controlUtilizator19.BackColor = System.Drawing.Color.White;
            this.controlUtilizator19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator19.Location = new System.Drawing.Point(393, 234);
            this.controlUtilizator19.Name = "controlUtilizator19";
            this.controlUtilizator19.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator19.TabIndex = 15;
            // 
            // controlUtilizator20
            // 
            this.controlUtilizator20.BackColor = System.Drawing.Color.White;
            this.controlUtilizator20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlUtilizator20.Location = new System.Drawing.Point(162, 90);
            this.controlUtilizator20.Name = "controlUtilizator20";
            this.controlUtilizator20.Size = new System.Drawing.Size(29, 32);
            this.controlUtilizator20.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(625, 476);
            this.Controls.Add(this.controlUtilizator11);
            this.Controls.Add(this.controlUtilizator12);
            this.Controls.Add(this.controlUtilizator13);
            this.Controls.Add(this.controlUtilizator14);
            this.Controls.Add(this.controlUtilizator15);
            this.Controls.Add(this.controlUtilizator16);
            this.Controls.Add(this.controlUtilizator17);
            this.Controls.Add(this.controlUtilizator18);
            this.Controls.Add(this.controlUtilizator19);
            this.Controls.Add(this.controlUtilizator20);
            this.Controls.Add(this.controlUtilizator10);
            this.Controls.Add(this.controlUtilizator9);
            this.Controls.Add(this.controlUtilizator8);
            this.Controls.Add(this.controlUtilizator7);
            this.Controls.Add(this.controlUtilizator6);
            this.Controls.Add(this.controlUtilizator5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.controlUtilizator4);
            this.Controls.Add(this.controlUtilizator3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.controlUtilizator2);
            this.Controls.Add(this.controlUtilizator1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private controlUtilizator controlUtilizator1;
        private controlUtilizator controlUtilizator2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private controlUtilizator controlUtilizator3;
        private controlUtilizator controlUtilizator4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private controlUtilizator controlUtilizator5;
        private controlUtilizator controlUtilizator6;
        private controlUtilizator controlUtilizator7;
        private controlUtilizator controlUtilizator8;
        private controlUtilizator controlUtilizator9;
        private controlUtilizator controlUtilizator10;
        private controlUtilizator controlUtilizator11;
        private controlUtilizator controlUtilizator12;
        private controlUtilizator controlUtilizator13;
        private controlUtilizator controlUtilizator14;
        private controlUtilizator controlUtilizator15;
        private controlUtilizator controlUtilizator16;
        private controlUtilizator controlUtilizator17;
        private controlUtilizator controlUtilizator18;
        private controlUtilizator controlUtilizator19;
        private controlUtilizator controlUtilizator20;
    }
}

